/**
 * Created by Ivana on 9.7.2015..
 */
define([
    'assets/js/smartDeviceDetect',
    'assets/js/smartFastClick',
    'assets/js/smartLayout',
    'assets/js/smartPageTitle',
    'assets/js/SmartCss',

    'components/layout/layoutModule',
    'components/homePage/homePageModule',


    'components/layout/layoutDirective'
])