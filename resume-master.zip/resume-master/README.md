# Personal Website built with AngularJS

This project is my personal portfolio website hosted on GitHub. Source code is located in the `src` folder and deployed to `gh-pages` with the `git-gh-deploy` script.

If you'd like to check this out locally run 

```
git clone git@github.com:ivanaszuber/resume.git resume/

cd /resume

bower install  #install alldependencies

```
